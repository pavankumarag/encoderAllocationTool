<?php
echo '<a href="index.php?content=availableEncoders">
				<span class="header ">Available encoders</span>
				
</a>
<br /><br />

<a href="index.php?content=selectEncoder">
				<span class="header ">Select Encoder</span>
</a>
<br /><br />

<a href="index.php?content=encoderAllocation">
				<span class="header ">Encoder Allocation Matrix</span>
</a>
<br /><br />

<a href="index.php?content=addEditEncoderAllocation">
				<span class="header ">Add/Edit Encoder Allocation</span>
</a>
<br /><br />
<!-- <img src="images/akamai_logo.jpg" alt="Akamai" style="width:10%;height:10%	"/> -->
';

if (isset($accessLevel) AND $accessLevel >= 99) {	

echo '<br /><br /><hr align=left style="width:250px" />
<p style="color: blue; font-weight: bolder;font-variant: small-caps"><u>Admin Panel</u></p>
<br />

<a href="index.php?content=listUsers">
				<span class="header ">List Users</span>
</a>
<br /><br />

<a href="index.php?content=createUser">
				<span class="header ">Create User</span>
</a>
<br /><br />

<a href="index.php?content=accessLog">
				<span class="header ">User Access Log</span>
</a>
<br /><br />';

}
echo '<hr align=left style="width:250px"/>

 <a href="index.php?status=logout ">
			<span class="header"><p style="color: blue; font-weight: bolder;font-variant: small-caps"><u>Logout</u></p></span>
			</a>';
	echo '<br /><br />'; 

?>