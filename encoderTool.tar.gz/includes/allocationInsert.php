<?php

$userName = $_POST['name'];
$startDate = $_POST['startDate'];
$releaseDate = $_POST['endDate'];
$encoderID = $_POST['encoderID'];

echo $userName ;
echo '<br />';
echo $startDate ;
echo '<br />';
echo $releaseDate ;
echo '<br />';
echo $encoderID ;
echo '<br />';
echo strtotime($startDate);
echo '<br />';
echo strtotime($releaseDate);
/* SELECT endDate FROM `eEncoderAllocation` WHERE encoderID="1" order by endDate desc */



echo '<br /><br />';
$epoch = 1344988800; 
$dt = new DateTime("@$epoch");  // convert UNIX timestamp to PHP DateTime
echo $dt->format('Y-m-d H:i:s'); // output = 2012-08-15 00:00:00 */

?>