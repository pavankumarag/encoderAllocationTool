<?php

echo "change password";
echo $userName ;
?>