
<html>
<head>
<title>Encoder Usage Management</title>
<link href="encoder_main.css" rel="stylesheet" type="text/css" />
</head>
<body>
<img src="images/akamai_logo.jpg" alt="Akamai" style="width:10%;height:10%	"/>

<div align="left",style="font-family: arial, helvetica, sans-serif;font-style: sans-serif;padding-left: 50px;">

<button type="button">
<a href="addEditEncoder.php">
				<span class="header ">Add/Edit Encoder or Encoder Details</span>				
</a>
</button>
<br /><br />


<button type="button">
<a href="companyCreate.php" >
				<span class="header ">List Consolidated Encoder Allocation</span>
</a>
</button>
<br /><br />

<a href="companyCreate.php">
				<span class="header ">List Per Encoder Allocation</span>
</a>
<br /><br />

<a href="companyCreate.php" >
				<span class="header ">New/Modify Encoder Allocation</span>
</a>
<br /><br />

</div>

<div align="center",style="font-family: arial, helvetica, sans-serif;font-style: sans-serif;">

<h1>Encoder Allocation Tool(EAT)</h1>

<h2>(EAT)</h2>
</div>
				  

</body>

</html>