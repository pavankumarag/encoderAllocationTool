<html>
<head>
<title>Encoder Usage Management</title>
<link href="encoder_main.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="header">
<h2 id="headerh">Encoder Allocation Tool(EAT)</h2>
</div>
<div id="content">
<img src="images/akamai_logo.jpg" alt="Akamai" style="width:8%;height:8%" align="right"/>

<div align="middle",style="font-family: arial, helvetica, sans-serif;font-style: sans-serif;padding-left: 100px;">

<h1>Encoder Allocation Tool(EAT)</h1>

<h2>(EAT)</h2>
</div>


<div id="content_right">
	<h2 style="color: red; font-weight: bolder;">*Please login to continue</h2>
			<form name="postLoginHid" action="hi.php" method="post">
			
					<P>User: 
					<INPUT TYPE=text NAME=username value="" SIZE=12 MAXLENGTH=16></P>
					<P>Password: 
					<INPUT TYPE=password NAME=password value="" SIZE=12 MAXLENGTH=16></P>
					<input type="submit"  value="Login" />
				
		</form>
		
</div>


<div id="content_left">

<a href="addEditEncoder.php">
				<span class="header ">Add/Edit Encoder or Encoder Details</span>
				
</a>
<br /><br />

<a href="companyCreate.php">
				<span class="header ">List Consolidated Encoder Allocation</span>
</a>
<br /><br />

<a href="companyCreate.php">
				<span class="header ">List Per Encoder Allocation</span>
</a>
<br /><br />

<a href="companyCreate.php">
				<span class="header ">New/Modify Encoder Allocation</span>
</a>
<br /><br />
<img src="images/akamai_logo.jpg" alt="Akamai" style="width:10%;height:10%	"/>
</div>


</div>
<div id="footer">

<p id="footerp">© 2014 Copyright . All rights reserved.</p>

</div>

</body>