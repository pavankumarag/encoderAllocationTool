<?php
	
$db = array(
'hostname' => 'localhost',
'username' => 'root',
'password' => 'root123',
'database' => 'encoderDb',
); 

?>