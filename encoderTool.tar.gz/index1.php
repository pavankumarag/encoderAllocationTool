<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Encoder Allocation Management</title>
<meta name="keywords" content="free blog template, css template, CSS, HTML" />
<meta name="description" content="Green Web Blog - free blog template provided by templatemo.com" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="templatemo_header_content_container">
        <div id="templatemo_header_section">
            <div id="templatemo_title_section">
        <pre>    EVENT DATA ANALYSIS </pre>
        </div> <!-- end of templatemo header panel -->
     </div>
        <div id="templatemo_content">

            <div id="templatemo_content_left">
                <h3>DATA ANALYSIS MYSTERY</h3>
<form action="/clicked" method="get"><pre>
<p>Host_IP          :  <input type="text" name="host_ip"><br>
Host_name        :  <input type="text" name="host_name"><br>	
Event_Time       :  <input type="text" name="event_time"><br>
Event_Category   :  <select>
 <option value="audit"> AUDIT </option>
 <option value="alert"> ALERT </option>
 <option value="security"> SECURITY </option>
<option value="all">ALL</option>
</select><br>
Active           :  <select>
 <option value="one"> 1 </option>
 <option value="zero"> 0 </option>
</select><br>
                    <input type="submit" style="color:orange;font:arial bold;background-color:blue;" value=" DISPLAY "> </pre>
</p><p>Click the "DISPLAY" button to get the processed data</p>
</form>
                    </div>
 <div id="templatemo_right_section">
<pre>
 <img src="images/da.jpg" alt="Not displayed"/> </pre>
</div>
</div>
            </div> <!-- end of content -->
    </div> <!-- end of content container -->
</html>